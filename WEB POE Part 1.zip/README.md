# Sipho's Plumbing & Maintenance — Website Project

## Student Information
- **Module:** Web Development (Introduction) — WEDE5020
- **Student Name:** Max [insert surname]
- **Student Number:** [insert student number]

## Project Overview
Sipho's Plumbing & Maintenance is a sole-proprietor plumbing business operating in
Johannesburg since 2016, offering residential and small-commercial plumbing, geyser
repairs, and general maintenance. This project builds a professional website for the
business to replace its current reliance on a Facebook page and word-of-mouth referrals.

The site is being built in three parts:
- **Part 1 — Building the Foundation:** planning, content research, HTML structure
- **Part 2 — Designing the Visuals:** CSS styling and responsive design
- **Part 3 — Adding Functionality and SEO:** JavaScript, forms, SEO, deployment

## Website Goals and Objectives
1. Generate qualified enquiry leads (quote requests) directly from the website.
2. Build trust and credibility ahead of a phone call or site visit.
3. Improve local search visibility for "plumber near me"-type searches.

**KPIs:** quote-form submissions per month, phone-click conversions, local search
ranking for target keywords.

## Key Features and Functionality
- Homepage with hero banner and service overview
- About Us page with company history, mission, vision and team
- Services page detailing plumbing, geyser, and maintenance offerings
- Enquiry page with a quote-request form
- Contact page with two service locations, a map, and a general contact form

## Timeline and Milestones
| Phase | Weeks | Focus |
|---|---|---|
| Part 1 | 1 – 4 | Planning, content gathering, HTML structure |
| Part 2 | 5 – 8 | CSS styling and responsive design |
| Part 3 | 9 – 12 | JavaScript functionality, forms, SEO, deployment |

## Part 1 Details

### File and Folder Structure
```
sipho-plumbing/
├── index.html
├── about.html
├── services.html
├── enquiry.html
├── contact.html
├── css/
│   └── style.css        (placeholder — styled in Part 2)
├── js/
│   └── script.js         (placeholder — built out in Part 3)
├── images/               (sourced images added here)
└── README.md
```

### Sitemap
```
Home (index.html)
├── About Us (about.html)
├── Services (services.html)
│   ├── Plumbing Repairs (#plumbing)
│   ├── Geyser Services (#geysers)
│   └── General Maintenance (#maintenance)
├── Get a Quote (enquiry.html)
└── Contact (contact.html)
```
All five pages share a common header (logo, navigation, "Call Now" button) and
footer (contact details, secondary navigation), as required by the module brief.

### Changelog
| Date | Change |
|---|---|
| 2026-08-14 | Initial project structure and Part 1 HTML pages created (index, about, services, enquiry, contact) |
| 2026-08-14 | Placeholder css/style.css and js/script.js added ahead of Parts 2 & 3 |
| 2026-08-14 | README.md created with project overview, sitemap and references |

## References
- Google Search Central. *SEO starter guide.* Available at: https://developers.google.com/search [Accessed 2026].
- GitHub Docs. *GitHub Pages.* Available at: https://docs.github.com/pages [Accessed 2026].
- Nielsen Norman Group. *Mobile UX for local service websites.* Available at: https://www.nngroup.com [Accessed 2026].
- MDN Web Docs. *HTML: A good basis for accessibility.* Available at: https://developer.mozilla.org [Accessed 2026].
